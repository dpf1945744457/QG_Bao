<template>
  <div><h1>位置信息</h1></div>
</template>

<script>
export default {
  name: 'PositionInformation'
}
</script>

<style>

</style>
