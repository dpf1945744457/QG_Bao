<template>
  <div><h1>修改密码</h1></div>
</template>

<script>
export default {
  name: 'ChangePassword'
}
</script>

<style>

</style>
